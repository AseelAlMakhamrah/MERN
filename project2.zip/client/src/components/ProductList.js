import React from 'react'
import axios from 'axios';
import {Link} from '@reach/router';
export default props => {
    return (
        <div>
            {props.product.map((product, index) => {
                return <h3 key={index}><Link to={`/${product._id}`}>{product.title}</Link></h3>
            })}
        </div>
    )
}