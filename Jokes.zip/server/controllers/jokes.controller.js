const {Joke } = require('../models/jokes.model');

module.exports.index = (request, response) => {
    response.json({
        message: "there is an JOKES"
    });
}
module.exports.createJoke = (request, response) => {
    Joke.create(request.body)
        .then(joke => response.json(joke))
        .catch(err => response.json(err));
}

module.exports.getAllJokes = (request, response) => {
    Joke.find({})
    .then(jokes => response.json(jokes))
    .catch(err => response.json(err));
}
module.exports.getJoke =( request,response) =>{
    Joke.findById({_id:request.params.id})
    .then(joke => response.json(joke))
    .catch(err => response.json(err));
}
module.exports.updateJoke =( request,response) =>{
    Joke.updateOne({_id:request.params.id},request.body,{new:true})
    .then(joke => response.json(joke))
    .catch(err => response.json(err));
}
module.exports.deleteJoke =( request,response) =>{
    Joke.deleteOne({_id:request.params.id})
    .then(joke => response.json(joke))
    .catch(err => response.json(err));
}
