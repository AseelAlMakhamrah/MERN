const JokeController = require('../controllers/jokes.controller');
const { Joke } = require('../models/jokes.model');
module.exports = function(app){
    app.get('/api', JokeController.index);
    app.get('/api/jokes/findAll', JokeController.getAllJokes);
    app.post('/api/jokes/create', JokeController.createJoke);
    app.get('/api/jokes/:id', JokeController.getJoke);
    app.put('/api/jokes/update/:id', JokeController.updateJoke);
    app.delete('/api/jokes/delete/:id', JokeController.deleteJoke);
}